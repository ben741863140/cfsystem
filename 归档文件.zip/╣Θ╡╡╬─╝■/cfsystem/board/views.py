from django.shortcuts import render
from board.models import RatingChange
from board.models import Board, BoardItem


# 榜单列表
def board_list():
    List = []
    for item in Board.objects.all():
        board = {'id': item.id, 'name': item.name, 'type': item.type, 'start_time': item.start_time,
                 'end_time': item.end_time}
        List.append(board)
    return List


# 查询榜是否存在
def board_exist(_id=-1):
    if Board.objects.filter(id=_id).exists():
        return True
    return False


def board_rating_operate(board_id=-1):
    class User(object):
        rank = rating = handle = oldRating = newRating = change = grade = times = 0
        nickname = realname = ''

        def keys(self):
            return ('rank', 'rating', 'handle', 'oldRating', 'newRating', 'change', 'nickname', 'realname')

        def __getitem__(self, item):
            return getattr(self, item)

    class User2(object):
        rank = rating = handle = grade = times = 0
        nickname = realname = ''

        def keys(self):
            return ('rank', 'rating', 'handle', 'nickname', 'realname')

        def __getitem__(self, item):
            return getattr(self, item)

    users = []
    if str("rating") == str(Board.objects.filter(id=board_id).get().type) or str(
            Board.objects.filter(id=board_id).get().type) == 'max_three':
        for item in BoardItem.objects.filter(board=Board.objects.filter(id=board_id).get()):
            info = User2()
            info.rating = item.max_rating
            info.handle = item.cf_user.handle
            info.realname = item.cf_user.realname
            info.grade = item.cf_user.grade
            if item.cf_user.user and item.cf_user.user.nickname:
                info.nickname = '(' + item.cf_user.user.nickname + ')'
            info.times = item.times
            users.append(info)
        users.sort(key=lambda x: x.rating, reverse=True)
        for i in range(len(users)):
            users[i].rank = i + 1
        return users
    else:
        for item in BoardItem.objects.filter(board=Board.objects.filter(id=board_id).get()):
            user = User()
            user.change = item.max_rating - item.old_rating
            if user.change <= 0:
                continue
            user.handle = item.cf_user.handle
            user.oldRating = item.old_rating
            user.newRating = item.max_rating
            user.realname = item.cf_user.realname
            user.times = item.times
            user.grade = item.cf_user.grade
            if item.cf_user.user and item.cf_user.user.nickname != '':
                user.nickname = '(' + item.cf_user.user.nickname + ')'
            users.append(user)
        users.sort(key=lambda x: x.change, reverse=True)
        for i in range(len(users)):
            users[i].rank = i + 1
            users[i].change = '+' + str(users[i].change)
        return users


def board_rating(request, board_id=-1):
    if not request.user.is_authenticated:
        return render(request, 'index.html')
    if board_id == -1:
        board_id = Board.objects.order_by('id').first().id
    time = Board.objects.filter(id=board_id).get().name
    creator = str(Board.objects.filter(id=board_id).get().creator)
    users = board_rating_operate(board_id)
    if str("rating") == str(Board.objects.filter(id=board_id).get().type) or str(Board.objects.filter(id=board_id)
                                                                                 .get().type) == 'max_three':
        return render(request, 'board/board_rating.html',
                      {'users': users, 'time': time, 'boards': Board.objects.all(), 'creator': creator})
    else:
        return render(request, 'board/board_upgrade.html',
                      {'users': users, 'time': time, 'boards': Board.objects.all(), 'creator': creator})


def board_rating_change(request, handle):
    if request.user.is_authenticated:
        queryset = RatingChange.objects.filter(cf_user__handle=handle)
        data = []
        for change in queryset:
            data.append([change.ratingUpdateTimeSeconds * 1000, change.newRating])
        data = str(data)[1:-1]
        return render(request, 'board/rating_change.html', {'data': data, 'name': handle})
    else:
        return render(request, 'index.html')


