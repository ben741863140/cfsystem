from web import web_start

web_start()
